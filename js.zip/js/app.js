function checkData(){

let alerts=[]

let age=document.getElementById("age").value
let exp=document.getElementById("exp").value
let marital=document.getElementById("marital").value
let children=document.getElementById("children").value
let degree=document.getElementById("degree").value
let job=document.getElementById("job").value

if(age<25 && exp>5){
alerts.push("Age and experience mismatch")
}

if(marital=="Single" && children>0){
alerts.push("Single person with children")
}

if(job=="Teacher" && degree=="No Degree"){
alerts.push("Teacher without degree")
}

localStorage.setItem("alerts",JSON.stringify(alerts))

window.location="alerts.html"

}

window.onload=function(){

let alerts=JSON.parse(localStorage.getItem("alerts"))

if(alerts){

let box=document.getElementById("alerts")

if(box){
alerts.forEach(a=>{
box.innerHTML+=`<div class="alert">${a}</div>`
})
}

let total=document.getElementById("total")
if(total){
total.innerText=alerts.length
}

}

}